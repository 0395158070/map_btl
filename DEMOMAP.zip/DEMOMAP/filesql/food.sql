SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

-- Cơ sở dữ liệu: `chuyende1`
CREATE TABLE `food` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `img` text NOT NULL,
  `address` varchar(250) NOT NULL,
  `lat` float(10,6) NOT NULL,
  `lon` float(10,6) NOT NULL,
  `type` varchar(30) NOT NULL,
  `descr` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Thêm data vào database
INSERT INTO `food` (`id`, `name`, `img`, `address`, `lat`, `lon`, `type`, `descr`) VALUES
(1, 'Trâu Hà Giang', 'https://vietfarms.com.vn/uploads/tin-tuc/thit-trau-gac-bep-ha-giang.jpg', 'BT1-1 Đường Đỗ Nhuận', 21.065659447556076, 105.79093678249421, 'Restaurant', 'Quán bia'),
(2, 'Nhà Hàng Cua Gạch', 'https://i.ytimg.com/vi/QyFlIbhycs4/maxresdefault.jpg', '205 Xuân Đỉnh', 21.06855283494751, 105.79634411532726, 'Restaurant', 'Nhà Hàng Cua'),
(3, 'Phong Dê Ninh Bình','https://ohay.vn/blog/wp-content/uploads/2020/03/nha-hang-hai-phong-1.1.jpg', 'BT 2.1 Đường Đỗ Nhuận', 21.06687087265589, 105.79424126366995, 'Restaurant', 'Quán dê'),
(4, 'Bia Long Viên','http://www.365bath.com/userfiles/images/14572215_1800627276819918_5438477333670189260_n.jpg', 'Khu ngoại giao đoàn', 21.067602999469443, 105.79677668539787, 'Restaurant', 'Quán Bia'),
(5, 'Lẩu Bà Thúy','https://diadiemnamdinh.com/wp-content/uploads/2017/12/lau-oc-ba-thuy-nam-dinh-1.jpg', 'BT 3 Đường Đỗ Nhuận', 21.0657506673822, 105.79127982806004, 'Restaurant', 'Quán Lẩu');

-- Chỉ mục cho bảng `food`
ALTER TABLE `food`
  ADD PRIMARY KEY (`id`);
COMMIT;