<?php
$host = 'localhost';
$user = 'root';
$pass = '';
$db = 'chuyende1';
$mysqli = new mysqli($host, $user, $pass, $db) or die($mysqli->error);

$id = array();
$name = array();
$img = array();
$address = array();
$lat = array();
$lon = array();
$type = array();
$descr = array();

// Chọn all các hàng trong bảng điểm đánh dấu
$query = "SELECT  * FROM food ";
$result = $mysqli->query($query) or die('Lỗi: ' . $mysqli->error);

while ($row = mysqli_fetch_array($result)) {
    $id[] = $row['id'];
    $name[] = $row['name'];
    $img[] = $row['img'];
    $address[] = $row['address'];
    $lat[] = $row['lat'];
    $lon[] = $row['lon'];
    $type[] = $row['type'];
    $descr[] = $row['descr'];
}
$count = mysqli_num_rows($result);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CHUYÊN ĐỀ 1 - NHÓM 01</title>
    <!-- boostrap -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"
        integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <!-- Popper JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <!-- Latest compiled JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <!--key map -->
    <script
            src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDWTx7bREpM5B6JKdbzOvMW-RRlhkukmVE&callback=initMap&libraries=places&v=weekly"
            defer
    ></script>
    <!-- css-->
    <link rel="stylesheet" href="css/style.css" type="text/css">
    <link rel="stylesheet" href="css/cssmap.css" type="text/css">
</head>

<body>
<div>
    <div class="row">
        <div class="col-sm-4">
            <img src="image/logo1.png" alt="logo website" style="width: 300px; border-radius: 10px;padding-top: 5px;">
        </div>

        <!-- CHỈ ĐƯỜNG -->
        <form class="form-inline my-2 my-lg-0" method="POST">
            <select class="form-control" id="end" name="end" style="width: 250px">
                <option>Chọn địa điểm</option>
                <?php
                $con = mysqli_connect("localhost", "root", "", "chuyende1");
                $sql = "SELECT name, lat, lon FROM food";
                $result = mysqli_query($con, $sql);

                while ($row = mysqli_fetch_array($result)) {
                    echo "<option value ={$row['lat']},{$row['lon']}>{$row['name']}</option>";
                }
                if (isset($_POST['end'])) {
                    if (!empty($_POST['end'])) {
                        $value = $_POST['end'];
                    }
                } else {
                    $value = 1;
                }
                ?>
            </select>
            <div style="width:10px"></div>
            <input class="btn btn-success my-2 my-sm-0" type="submit" value="Chỉ đường">
        </form>

        <div id="people">
            <img src="image/pic1.jpg" style="width:35px;height:35px;border-radius: 25px;">
            <p>NHÓM 1</p>
        </div>
    </div>
<!--KẾT THÚC ROW 1-->

    <div class="example">
        <ul id="nav">
            <!-- Sửa địa điểm -->
            <li class="current">
                <a href="javascript:void(0)" data-toggle="modal" data-target="#correctitem">Sửa Địa Điểm </a></li>
            <div class="modal fade" id="correctitem" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">

                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Nhập địa điểm bạn muốn sửa</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>

                        <div class="modal-body">
                            <div class="form-group">
                                <form method="POST">
                                    <label for="usr">Tên địa điểm:</label>
                                    <select class="form-control" id="uid" name="uid" style="width: 100%">
                                        <option value="">Chọn địa điểm</option>
                                        <?php
                                        $con = mysqli_connect("localhost", "root", "", "chuyende1");
                                        $sql = "SELECT id, name FROM food";
                                        $result = mysqli_query($con, $sql);
                                        while ($row = mysqli_fetch_array($result)) {
                                            echo "<option value ={$row['id']}>{$row['name']}</option>";
                                        }
                                        ?>
                                    </select>
                            </div>

                            <div class="form-group">
                                <label for="pwd">Chọn cột sửa:</label>
                                <select class="form-control" id="utype" name="utype" style="width: 100%">
                                    <option>Chọn cột sửa</option>
                                    <option value="name">Tên quán</option>
                                    <option value="img">Đường dẫn ảnh</option>
                                    <option value="address">Địa chỉ quán</option>
                                    <option value="lat">Kinh độ</option>
                                    <option value="lon">Vĩ độ</option>
                                    <option value="type">Loại hình</option>
                                    <option value="descr">Mô tả</option>
                                </select>
                            </div>

                            <div class="form-group">
                                <label for="pwd">Nhập nội dung:</label>
                                <textarea id="uc" name="uc" class="form-control" rows="5"></textarea>
                            </div>                          
                        </div>

                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Đóng</button>
                            <input name='update' type="submit" class="btn btn-primary" value='Lưu lại'>
                            </form>
                            <?php
                            $con = mysqli_connect("localhost", "root", "", "chuyende1");
                            if (isset($_POST['update'])) {
                                if (!empty($_POST['uid']) || !empty($_POST['utype']) || !empty($_POST['uc'])) {
                                    $id = $_POST['uid'];
                                    $type = $_POST['utype'];
                                    $content = $_POST['uc'];
                                    $sql = "UPDATE food SET $type = '$content' WHERE id = '$id'";
                                    $result = mysqli_query($con, $sql);
                                } else {
                                    echo 'Vui lòng chọn giá trị.';
                                }
                                echo "<meta http-equiv='refresh' content='0'>";
                            }
                            ?>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Xóa địa điểm -->
            <li class="current"><a href="javascript:void(0)" data-toggle="modal" data-target="#deleteitem">Xóa Địa Điểm </a></li>
            <div class="modal fade" id="deleteitem" tabindex="-1" aria-labelledby="exampleModalLabel"
                 aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Xoá địa điểm</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <div class="form-group">
                                <form method="POST">
                                    <label for="usr">Tên địa điểm:</label>
                                    <select class="form-control" id="slname" name="slname" style="width: 100%">
                                        <option value="">Chọn địa điểm</option>
                                        <?php
                                        $con = mysqli_connect("localhost", "root", "", "chuyende1");
                                        $sql = "SELECT id, name FROM food";
                                        $result = mysqli_query($con, $sql);
                                        while ($row = mysqli_fetch_array($result)) {
                                            echo "<option value ={$row['id']}>{$row['name']}</option>";
                                        }
                                        ?>
                                    </select>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Đóng</button>
                            <input name='delete' type="submit" class="btn btn-primary" value='Xóa địa điểm'>
                            </form>
                            <?php
                            $con = mysqli_connect("localhost", "root", "", "chuyende1");
                            if (isset($_POST['delete'])) {
                                if (!empty($_POST['slname'])) {
                                    $selected = $_POST['slname'];
                                    $sql1 = "SELECT name from food WHERE id= '$selected'";
                                    $result1 = $mysqli->query($sql1);
                                    while ($row = mysqli_fetch_array($result1)) {
                                        $name = $row['name'];
                                    }
                                    $sql = "DELETE FROM food WHERE id = '$selected'";
                                    if ($con->query($sql) === true) {
                                        echo "<script> alert('Đã xoá thành công $name bạn vừa chọn');</script>";
                                    } else {
                                        echo "<script>alert('Lỗi. $con->error');</script>";
                                    }
                                } else {
                                    echo '<script>alert("Hãy chọn một địa điểm bạn muốn xoá.");</script>';
                                }
                                echo "<meta http-equiv='refresh' content='0'>";
                            }
                            ?>
                        </div>
                    </div>
                </div>
            </div>

        </ul>
    </div>
</div>

<div id="map"></div>
<script>
    function initMap() {
        var options = {
            zoom: 12,
            center: {lat: 21.0723936, lng: 105.7738397}
        }

        var map = new google.maps.Map(document.getElementById('map'), options);
    
        var name = <?php echo json_encode($name) ?>;
        var img = <?php echo json_encode($img) ?>;
        var add = <?php echo json_encode($address) ?>;
        var lat = <?php echo json_encode($lat) ?>;  // Kinh độ
        var lon = <?php echo json_encode($lon) ?>;  // Vĩ độ
        var descr = <?php echo json_encode($descr) ?>;
        var count = <?php echo json_encode($count) ?>;
        for (var i = 0; i < count; i++) {
            var a = parseFloat(lat[i]);
            var o = parseFloat(lon[i]);
            var d = '<img src="' + img[i] + '" style="width:260px; height:160px;"><br><h5>' 
            + name[i] + '</h5><br><h6>(' + descr[i] + ')</h6><br><h6>Địa chỉ: ' + add[i] + '</h6><br><h6>lat: ' + lat[i] + ', lng: ' + lon[i] + '</h6>';
            var markers = [{
                coords: {lat: a, lng: o},
                content: d,
                iconImage: 'https://www.gstatic.com/earth/images/stockicons/190201-2116-fast-food_4x.png', // Icon địa điểm quán
            }];
            addMarker(markers[0]);
        }

        function addMarker(props) {
            var marker = new google.maps.Marker({
                position: props.coords,
                map: map,
            });

            if (props.iconImage) {

                marker.setIcon(props.iconImage);
            }
            // Check content
            if (props.content) {
                var infoWindow = new google.maps.InfoWindow({
                    content: props.content
                });
                marker.addListener('click', function () {
                    infoWindow.open(map, marker);
                });
            }
        }

        var infoWindow = new google.maps.InfoWindow({
            content: 'Click "Cho phép" để định vị vị trí của bạn',
        });
        infoWindow.open(map);

        map.addListener("click", function (mapsMouseEvent) {
            infoWindow.close();
            infoWindow = new google.maps.InfoWindow({
                position: mapsMouseEvent.latLng,
            });
            infoWindow.setContent(mapsMouseEvent.latLng.toString());
            infoWindow.open(map);
        });

        // BẠN ĐANG Ở ĐÂY 
        navigator.geolocation.getCurrentPosition(showPosition);
        function showPosition(p) {
            mylat = p.coords.latitude;
            mylon = p.coords.longitude;
            // Xác định vị trí của bạn
            var marker = new google.maps.Marker({
                position: {lat: mylat, lng: mylon},
                map: map,
                animation: google.maps.Animation.BOUNCE,
                icon: {
                    url: 'https://cdn3.iconfinder.com/data/icons/maps-and-navigation-7/65/68-512.png',
                    scaledSize: {width: 60, height: 60},
                },
                title: 'BẠN ĐANG Ở ĐÂY'
            });

            // Bản đồ chỉ đường
            const directionsService = new google.maps.DirectionsService();
            const directionsRenderer = new google.maps.DirectionsRenderer();
            directionsRenderer.setMap(map);
            calculateAndDisplayRoute(directionsService, directionsRenderer);
        }

        var temp = <?php echo json_encode($value) ?>;
        if (temp != "1") {
            for (var i = 0; i < temp.length; i++) {
                if (temp[i] == ",") {
                    var at = parseFloat(temp.substr(0, i - 1));
                    var on = parseFloat(temp.substr(i + 1, temp.length));
                }
            }

            function calculateAndDisplayRoute(directionsService, directionsRenderer) {
                directionsService.route(
                    {
                        origin: {lat: mylat, lng: mylon},
                        destination: {lat: at, lng: on},
                        travelMode: google.maps.TravelMode.DRIVING,
                        //  WALKING , BICYCLING, TRANSIT 
                    },
                    (response, status) => {
                        if (status === "OK") {
                            directionsRenderer.setDirections(response);
                        } else {
                            window.alert("Yêu cầu chỉ đường của bạn không thành công do " + status);
                        }
                    }
                );
            };
        }
    }
</script>
<div class="footer">
    <div> &copy copyright - NHÓM 01</div>
</div>
</body>
</html>